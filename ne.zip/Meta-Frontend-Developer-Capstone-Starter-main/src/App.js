import React from 'react';
import './App.css';

function App() {
  return (
 
    <div>
      <h1>Meta Frontend Developer Capstone Starter Files</h1>
    </div>
  );
}

export default App;
